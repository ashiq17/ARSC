<?php $this->load->view('common/header'); ?>
<!--************************************
        Inner Banner Start
    *************************************-->
<div class="tg-innerbanner">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <ol class="tg-breadcrumb">
                    <li><a href="javascript:void(0);">সংবাদ ও ঘটনাবলী</a></li>
                    <li class="tg-active">আমাদের সাফল্য</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!--************************************
    Inner Banner End
*************************************-->
<?php $this->load->view('common/SidebarLeft'); ?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
    <div class="panel">
        <h2>আমাদের সাফল্য</h2>
        <div class="panel-body">
            <br>
              <!-- <img src="<?php echo base_url(); ?>/assets/website/images/slider/arsc2.jpg"><br>
              <br>
              
              <img src="<?php echo base_url(); ?>/assets/website/images/slider/arsc3.jpg"> -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 

                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১২</strong><br />আফরিনা জাহান নীলিমা <br />বৃত্তিসহ জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১২</strong><br />ফাইরুজ সাইমা  <br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১২</strong><br /> হুমাইয়া আক্তার ইকরা<br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১২</strong><br /> মো: ওমর ফারুক<br /> জিপিএ-৫<br /> 
                                </address>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১৩</strong><br />সাবরিনা ফেরদৌস উপমা<br />জিপিএ-৫<br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১৩</strong><br />মোসা: জোহানা রহমান<br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১৩</strong><br /> সৈয়দা আনিকা রহমান<br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১৪</strong><br /> তানজীম সুবাইতা রায়া<br /> জিপিএ-৫<br /> 
                                </address>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১৬</strong><br />মোসা: অহনা রহমান<br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>সমাপনী পরীক্ষা-২০১৬</strong><br />জান্নাতুল মদিনা<br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা -২০১৩</strong><br />নুসরাত জামান রায়া <br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা -২০১৩</strong><br /> তানমীম চৌধুরী শ্রেয়া <br /> জিপিএ-৫<br /> 
                                </address>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা -২০১৫</strong><br />আফরিনা জাহান নীলিমা<br />বৃত্তিসহ জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা -২০১৫</strong><br />ফাইরুজ সাইমা  <br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা -২০১৫</strong><br /> হুমাইয়া আক্তার ইকরা<br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা -২০১৫</strong><br /> মো: ওমর ফারুক<br /> জিপিএ-৫<br /> 
                                </address>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 

                                <address>
                                    <strong>জেএসসি পরীক্ষা -২০১৫</strong><br />ইব্রাহিম খলিল উল্লাহ উদয়<br />  জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা-২০১৬</strong><br />সাবরিনা ফেরদৌস উপমা<br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা-২০১৬</strong><br /> মোসা: জোহানা রহমান<br />জিপিএ-৫ <br /> 
                                </address>
                            </div>
                            <div class="col-md-3">
                                <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                                <address>
                                    <strong>জেএসসি পরীক্ষা-২০১৬</strong><br /> সৈয়দা আনিকা রহমান <br /> জিপিএ-৫<br /> 
                                </address>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-3">
                            <img alt=" Image Preview" src="" class="img-thumbnail" /> 

                            <address>
                                <strong>এসএসসি পরীক্ষা-২০১৬</strong><br />নুসরাত জামান রায়া <br />  জিপিএ-৫ <br /> 
                            </address>
                        </div>
                        <div class="col-md-3">
                            <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                            <address>
                                <strong>এসএসসি পরীক্ষা-২০১৭</strong><br />আফরিনা জাহান নীলিমা<br />জিপিএ-৫ <br /> 
                            </address>
                        </div>
                        <div class="col-md-3">
                            <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                            <address>
                                <strong>জএসএসসি পরীক্ষা-২০১৭</strong><br /> মালেকা পারভেজ চন্দ্রিমা<br />জিপিএ-৫ <br /> 
                            </address>
                        </div>
                        <!-- <div class="col-md-3">
                          <img alt=" Image Preview" src="" class="img-thumbnail" /> 
                          <address>
                             <strong>জেএসসি পরীক্ষা -২০১৫</strong><br /> মো: ওমর ফারুক<br /> জিপিএ-৫<br /> 
                          </address>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('common/SidebarRight'); ?>
<?php $this->load->view('common/footer'); ?>