<?php $this->load->view('common/header');?>

<!--************************************
				Inner Banner Start
		*************************************-->
<div class="tg-innerbanner">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<ol class="tg-breadcrumb">
					<li><a href="javascript:void(0);">আমাদের কথা</a></li>
					<li class="tg-active">আমাদের বৈশিষ্ট্য</li>
				</ol>
			</div>
		</div>
	</div>
</div>
		<!--************************************
				Inner Banner End
		*************************************-->

<?php $this->load->view('common/SidebarLeft');?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
	<div class="panel">
		<div class="panel-body">
			<article class="tg-themepost tg-course">				
				<div class="tg-themetabs tg-coursestabs">
					<div class="tab-content tg-themetabcontent">
						<div role="tabpanel" class="tab-pane active" id="description">
							<img src="<?php echo base_url(); ?>/assets/website/images/authors/img-02.jpg">
							<h2>আমাদের বৈশিষ্ট্য</h2>
							<p>শিক্ষা ক্যাম্পাস:<br>
							বর্তমান ৭ তলা একাডেমিক ভবনটির মালিক প্রতিষ্ঠাতা নিজেই। নিচতলায় শিক্ষার্থীদের অ্যাসেম্ব্লী অনুষ্ঠিত হয়। ভবিষ্যৎ পরিকল্পনা অনুযায়ী খোলামেলা পরিবেশে প্রতিষ্ঠানের জন্য প্রয়োজনীয় সুযোগ-সুবিধাসহ অবকাঠামো নির্মাণের কাজ শেষ হলে প্রতিষ্ঠানটি সেখানে স্থানান্তর করা হবে।
							</p>

							<h4>অন্যান্য বিশেষ আকর্ষণসমূহ:</h4>
							<ul>
								<br>
								<li>
									* সুসজ্জিত শ্রেণিকক্ষ। সিসি টিভি দ্বারা পাঠদান পর্যবেক্ষণ। 
								</li><li>
									* মাল্টিমিডিয়া প্রজেক্টরের মাধ্যমে পাঠদান।
								</li><li>
									* সুশৃঙ্খল পরিবেশ ও কঠোর নিরাপত্তা ব্যবস্থা।
								</li><li>
									* গরীব মেধাবী শিক্ষার্থীদেরকে আর্থিক সুবিধা প্রদান।
								</li><li>
									* শিক্ষার্থীদেরকে টিফিন ও স্টেশনারী দ্রব্য সরবরাহের জন্য ক্যান্টিনের ব্যবস্থা।
								</li><li>
									 * একাডেমিক ক্যালেন্ডার ও ও বাৎসরিক পাঠ্যসূচী (ঝুষষধনঁং) বৎসরের শুরুতে সরবরাহ এবং তা অনুসরণ।
								</li>
							</ul>
						</div>
					</div>
				</div>
			</article>
		</div>
	</div>
</div>

<?php $this->load->view('common/SidebarRight');?>
<?php $this->load->view('common/footer');?>