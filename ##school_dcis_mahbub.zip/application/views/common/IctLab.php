<?php $this->load->view('common/header');?>

<!--************************************
        Inner Banner Start
    *************************************-->
    <div class="tg-innerbanner">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <ol class="tg-breadcrumb">
              <li><a href="javascript:void(0);">Facilities & Services</a></li>
              <li class="tg-active">ICT LAB</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--************************************
        Inner Banner End
    *************************************-->
<?php $this->load->view('common/SidebarLeft');?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
	<div class="panel">
		<div class="panel-body">
			<h2>ICT LAB</h2>
				<img src="<?php echo base_url(); ?>/assets/website/images/authors/img-06.jpg">
												
				<p><br>The Computer Lab is used for practical classes for Computing Studies. Students from STD II TO STD X onwards are taught various applications and are also guided for the preparation of their O’ Level Computing Coursework

The practical classes and the lab itself are designed to ensure continuous monitoring of students’ work, while the computers are well-equipped to meet course requirements. On the other hand, respective ICT Teachers execute their classes   using multimedia projector to make the study more understandable and presentable. Students can easily gather experience on networking activities using file sharing option. In near future School Management are going to implement Remote Access Control Service (RACS) for the student’s so that respective ICT Teachers can help the learners in the best manner. MEMS Also providing audiovisual opportunities for students to reinforce academic knowledge.</p>
			
			
		</div>
	</div>

</div>

<?php $this->load->view('common/SidebarRight');?>
<?php $this->load->view('common/footer');?>