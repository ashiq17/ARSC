<?php $this->load->view('common/header');?>
<!--************************************
        Inner Banner Start
    *************************************-->
    <div class="tg-innerbanner">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <ol class="tg-breadcrumb">
              <li><a href="javascript:void(0);">News & Events</a></li>
              <li class="tg-active">Notice & Announcement</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--************************************
        Inner Banner End
    *************************************-->
<?php $this->load->view('common/SidebarLeft');?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
	<div class="panel">
		<div class="panel-body">
			<h2>Notice & Announcement</h2>
			
		</div>
	</div>

</div>

<?php $this->load->view('common/SidebarRight');?>
<?php $this->load->view('common/footer');?>