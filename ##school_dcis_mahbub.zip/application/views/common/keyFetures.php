<?php $this->load->view('common/header');?>

<!--************************************
				Inner Banner Start
		*************************************-->
		<div class="tg-innerbanner">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<ol class="tg-breadcrumb">
							<li><a href="javascript:void(0);">About Us</a></li>
							<li class="tg-active">Key Fetures</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
		<!--************************************
				Inner Banner End
		*************************************-->

<?php $this->load->view('common/SidebarLeft');?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
	<div class="panel">
		<div class="panel-body">
			
		<article class="tg-themepost tg-course">
									
								
										<div class="tg-themetabs tg-coursestabs">
										
											<div class="tab-content tg-themetabcontent">
												<div role="tabpanel" class="tab-pane active" id="description">
												
													<img src="<?php echo base_url(); ?>/assets/website/images/authors/img-02.jpg">
													<ul>
														<li>
															Cyberdyne School has spacious,comfortable and well decorated classrooms and maintains the
														</li><li>
															standard classroom teaching of maximum 30 students per class. It ensures full time generator facilities.
														</li><li>
															All classes are taught in English in the context of our national life and literature.However
														</li><li>
															It follows the curriculum and syllabus of the Aducation Board.
														</li><li>
															Cyberdyne School is committed to share and maximize Child’s potential through task base teaching
														</li><li>
															 Cyberdyne School has modern air conditioned Computer and science laboratories and Library.
														</li><li>
															school will be very much determined to maintain strong discipline without any compromise.
														</li><li>
															Cyberdyne School has its own campus with two buildings with a large play ground.
														</li>
													</ul>
										
												</div>
											</div>
										</div>
									</article>
		</div>
	</div>

</div>

<?php $this->load->view('common/SidebarRight');?>
<?php $this->load->view('common/footer');?>