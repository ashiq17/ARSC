<?php $this->load->view('common/header');?>
 <!--************************************
        Inner Banner Start
    *************************************-->
    <div class="tg-innerbanner">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <ol class="tg-breadcrumb">
              <li><a href="javascript:void(0);">Admission</a></li>
              <li class="tg-active">How To Apply</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--************************************
        Inner Banner End
    *************************************-->
<?php $this->load->view('common/SidebarLeft');?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
	<div class="panel">
		<div class="panel-body">
			
			<article class="tg-themepost tg-course">
									
								
										<div class="tg-themetabs tg-coursestabs">
										
											<div class="tab-content tg-themetabcontent">
												<div role="tabpanel" class="tab-pane active" id="description">
												
												<h3>How to Apply</h3>
													<img width="100%" src="<?php echo base_url(); ?>/assets/website/images/authors/img-05.jpg">
												<ol type="1">
													<li>
														Parent(s) will initially collect the Admission Test Form(s) from the School Office.
													</li>
													<li> Parent(s) should submit the filled in form(s) within the given date(s) and collect</li>

													<li>On the submission of the filled in Admission Test Form(s),parents must submit the</li>

													<li>Certificate(s) issued by City Corporation/Union Council/Clinic/Hospital vaccination card etc. and two copy stamp size photographs of the applicant(s) and the photocopy of the last Exam’s Report Card(s) (if possible).</li>

													<li>  Applicant(s) must face both written and Viva. No written test will be held for  play

Group student(s).</li>

												
												</ol>
										
												</div>
											</div>
										</div>
									</article>
		</div>
	</div>

</div>

<?php $this->load->view('common/SidebarRight');?>
<?php $this->load->view('common/footer');?>