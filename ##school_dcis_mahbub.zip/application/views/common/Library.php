<?php $this->load->view('common/header');?>
<!--************************************
        Inner Banner Start
    *************************************-->
    <div class="tg-innerbanner">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <ol class="tg-breadcrumb">
              <li><a href="javascript:void(0);">Facilities & Services</a></li>
              <li class="tg-active">Library</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--************************************
        Inner Banner End
    *************************************-->
<?php $this->load->view('common/SidebarLeft');?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
	<div class="panel">
		<div class="panel-body">
			<h2>Library</h2>
				<img src="<?php echo base_url(); ?>/assets/website/images/authors/img-07.jpg">
												
				<p><br>Cyberdyne School (CS) maintains a rich library which is situated at 2nd floor of the Campus  With over 5,000 books and audio-visual resources from Edexcell. It has an attractive facility and large accommodation for our students. CS library support and enhance our educational goals. It also provide programs and resources to develop and sustain in children the habit of reading and learning and the use of library throughout their lives. Our Library provide access to resources, recreation books, information and materials to support all educational programs and develop a love for learning.

CS  school library from which students may borrow books regularly or conduct research. CS also endow with audiovisual opportunities for students to reinforce academic knowledge.</p>
			
			
		</div>
	</div>

</div>

<?php $this->load->view('common/SidebarRight');?>
<?php $this->load->view('common/footer');?>