
<?php $this->load->view('common/header');?>
<?php $this->load->view('common/main_body');?>
<?php $this->load->view('common/footer');?>


