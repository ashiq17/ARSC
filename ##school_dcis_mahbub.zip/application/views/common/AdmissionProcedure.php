<?php $this->load->view('common/header');?>
 <!--************************************
        Inner Banner Start
    *************************************-->
    <div class="tg-innerbanner">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <ol class="tg-breadcrumb">
              <li><a href="javascript:void(0);">Admission</a></li>
              <li class="tg-active">Admission Procedure</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--************************************
        Inner Banner End
    *************************************-->
<?php $this->load->view('common/SidebarLeft');?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
	<div class="panel">
		<div class="panel-body">

			<article class="tg-themepost tg-course">


				<div class="tg-themetabs tg-coursestabs">

					<div class="tab-content tg-themetabcontent">
						<div role="tabpanel" class="tab-pane active" id="description">

							<h3>Admission Procedure and Policy</h3>
						<!-- 	<img width="100%" src="<?php echo base_url(); ?>/assets/website/images/authors/img-05.jpg"> -->
						<ul type="square">
								<li>
									Parent(s) will initially collect the Admission Test Form(s) from the School Office.
								</li>
								<li> Parent(s) should submit the filled in form(s) within the given date(s) and collect</li>

								<li>On the submission of the filled in Admission Test Form(s),parents must submit the</li>

								<li>On the submission of filled in Admission Test Form(s) parent(s)must submit the Birth
									Certificate(s) issued by City Corporation /Union Council/Clinic/Hospital Vaccination Card etc
									and two (02) stamp size photographs of the applicant(s) and the photocopy of last exam’s
								Report Card(s) (if possible).</li>

								<li> Applicant(s) must face both written and viva. No written test will be held for play Group
								Student(s).</li>
								<li>Parents ( both Father and Mother ) must be present for Viva</li>
								<li>Applicant(s) approved for admission will be notified through the school office Notice Board.</li>
								<li>Applicant(s) eligible for admission will be asked to collect main Application Form(s) from
									the school  office and submit the filled in form(s) on the specific date(s) along with the
									required papers and documents.Main Application Form(s) may be collected on any working
								on the payment of the requisite fee (from 9:00 am to 1 pm on all working days)</li>
								<li>Admission Form(s) and other form(s) must be duly and completely filled in by the parents.
									Admission should be taken within the given date(s) from the school office.Four(04) stamp
									size photographs of student(s) and one(01) stamp size, one(01) passport size photographs
								of each of the parents or guardians must be submitted to the school office during admission.</li>
								<li>The name of the Candidate(s) will be registered during the issuance of Application Form(s).</li>
								<li>Enrollment of Old student(s) should be completed as per schedule given from the office.</li>
								<li>Enrollment of New Student(s) should be completed as per schedule given from the office.</li>
								<li>In exceptional cases, applicant(s) for new admission into any class during any time of the
								year will be under special consideration by the School Authority.</li>
								<li>New admission is considered on the basis of previous school record(s), personal interview(s)
								and the result(s) of the Admission test.</li>


							</ul>

						</div>
					</div>
				</div>
			</article>
		</div>
	</div>

</div>

<?php $this->load->view('common/SidebarRight');?>
<?php $this->load->view('common/footer');?>