<?php $this->load->view('common/header');?>
<!--************************************
        Inner Banner Start
    *************************************-->
    <div class="tg-innerbanner">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <ol class="tg-breadcrumb">
              <li><a href="javascript:void(0);">Facilities & Services</a></li>
              <li class="tg-active">Playing Facilities</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--************************************
        Inner Banner End
    *************************************-->
<?php $this->load->view('common/SidebarLeft');?>

<div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 pull-center">
	<div class="panel">
		<div class="panel-body">
			<h2>Playing Facilities</h2>
				<img src="<?php echo base_url(); ?>/assets/website/images/authors/img-09.jpg">
				<img src="<?php echo base_url(); ?>/assets/website/images/authors/img-08.jpg">
												
				<p><br>An organized Physical Education Program is also an integral part of the curriculum. MEMS school buildings have playing areas, and qualified teachers supervise sports classes.

Specially for play group students MEMS has equipped updated playing instruments, so that they find their time with pleasure. In that case  MEMS is really keen to involve them and helping them to build up with sporting men

Students may participate in tournaments and matches after school hours or on weekends. Students also take part in various competitions organized by different federations. Transport is often provided for such occasions but students may be asked to arrange for their own transportation for these events.

We are particularly proud of our sports teams, developed in School, that have been successful in countless tournaments and sporting events throughout the year.. MEMS students challenge others in football, handball, Volleyball and cricket etc.</p>
			
			
		</div>
	</div>

</div>

<?php $this->load->view('common/SidebarRight');?>
<?php $this->load->view('common/footer');?>